<?php
/**
 * huggaccounting functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package huggaccounting
 */

//Custom Theme Setup
if (!function_exists('huggaccounting_setup'))
{
    function huggaccounting_setup()
    {
        add_theme_support('title-tag');
    }
}

add_action('after_setup_theme', 'huggaccounting_setup');

//Add Custom Scripts
if (!function_exists('huggaccounting_scripts'))
{
    function huggaccounting_scripts()
    {
        wp_enqueue_style('huggaccounting-google-fonts', 'https://fonts.googleapis.com/css?family=Montserrat:400,700|Archivo+Black:400');
        wp_enqueue_style('huggaccounting-styles', get_template_directory_uri().'/css/style.css');
        wp_enqueue_style('bootstrap', get_template_directory_uri().'/css/bootstrap.min.css');
        wp_enqueue_script('bootstrap', get_template_directory_uri().'/js/bootstrap.min.js', array('jquery'), null, true);
    }
}
add_action('wp_enqueue_scripts', 'huggaccounting_scripts');