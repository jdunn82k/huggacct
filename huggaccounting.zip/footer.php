<footer class="rgb22 pt-1 pb-4">
    <p class="text-white text-center montserrat-font">Copyright &copy; 2018 Hugg Accounting, Inc. - All Rights Reserved</p>
</footer>